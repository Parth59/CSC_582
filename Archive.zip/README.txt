Afterlife - A Game about Life after Death
Created by: Nick Garner, Parth Kanakiya, and Jonathan Nguyen

This html file contains the following deliverable
A) Deliveable 2 (Part 2 of deliverable 2) 
B) Deliverable 4

To run the game:
1. Download the file Afterlife.html
2. Navigate to your Downloads folder
3. Double-click the Afterlife.html file to run the game in your default browser.
4. Have fun!

